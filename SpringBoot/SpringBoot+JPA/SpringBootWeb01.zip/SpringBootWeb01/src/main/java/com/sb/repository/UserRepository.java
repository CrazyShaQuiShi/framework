package com.sb.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sb.entities.User;

@Repository
public interface UserRepository extends CrudRepository<User, Integer> {

	/**
	 * 根据Id查询User
	 * @param id
	 * return User
	 */
	public User findOne(Integer id);
	/**
	 * 查询所有User
	 */
	public List<User> findAll();
	
}
