package com.sb.web;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/Custome")
public class CustomeController {

	@RequestMapping("/hello")
	String hello(String name) {
		System.out.println(name);
		return "hello " + name;
	}

	@RequestMapping("/hello2/{newName}")
	String hello2(@PathVariable String newName) {
		System.out.println(newName);
		return newName;
	}

	
}
