package com.sb.web;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sb.entities.User;
import com.sb.repository.UserRepository;

@Controller
@RequestMapping("/User")
public class UserController {

	@Autowired
	private UserRepository userRepository;

	@RequestMapping("/user")
	public String getUserById(Integer id, HttpServletRequest request) {
		System.out.println("hello user");
		User u = userRepository.findOne(id);
		System.out.println(userRepository);
		System.out.println(u);
		request.setAttribute("msg", u);
		return "index";
	}
	@RequestMapping("/getall")
	@ResponseBody
	public List<User> getList(){
		List<User> list=userRepository.findAll();
		return list;
	}

	@RequestMapping("/index")
	public String index(HttpServletRequest request) {
		request.setAttribute("msg", "hello world！");
		return "index";
	}
}
