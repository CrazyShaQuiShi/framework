package com.dd.dispatch;

public class A {

	public static void main(String[] args) {
		a(123);
		
		
	}
	
	public static void a(Object o){
		if(o instanceof Integer){
			
			System.out.println("是整形");
		}else{
			System.out.println("不是");
		}
	}
}
