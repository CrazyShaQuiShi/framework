package com.dd.dispatch.domain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.dd")
@EnableAutoConfiguration
public class SysConfiguration {

	public static void main(String[] args) {
		SpringApplication.run(SysConfiguration.class, args);
	}
}
