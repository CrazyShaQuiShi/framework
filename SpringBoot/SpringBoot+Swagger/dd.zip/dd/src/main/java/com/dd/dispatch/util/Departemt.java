package com.dd.dispatch.util;

public enum Departemt {
	/**
	 * 城市管理行政执法局
	 */
	CHGLXZZFJ,
	/**
	 * 建筑工程管理局
	 */
	JZGCGLJ,
	/**
	 * 交通局
	 */
	JTJ,
	/**
	 * 民政局
	 */
	MZJ,
	/**
	 * 气象局
	 */
	QXJ,
	/**
	 * 水利局
	 */
	SLJ,
	/**
	 * 文广新局
	 */
	WGXJ,
	/**
	 * 新区办
	 */
	XQB,
	/**
	 * 信访局
	 */
	XFJ,
	/**
	 * 中国电信温岭分公司
	 */
	ZGDXWLFGS,
	/**
	 * 中国联通（网通）温岭分公司
	 */
	ZGLTWLFGS,
	/**
	 * 工商局
	 */
	GSJ,
	/**
	 * 中国移动（铁通）温岭分公司
	 */
	ZGYDWLFGS,
	/**
	 * 公安局
	 */
	GAJ,
	/**
	 * 供电局
	 */
	GDJ,
	/**
	 * 广播电视台
	 */
	GBDT,
	/**
	 * 行政执法局
	 */
	XZZFJ,
	/**
	 * 环保局
	 */
	HBJ,
	/**
	 * 建设规划局
	 */
	JSGHJ
}
