package com.dd.dispatch.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DispathUtil {

	private static DispathUtil dispathUtil = new DispathUtil();

	private DispathUtil() {
	}

	public static DispathUtil getInstance() {
		if (dispathUtil == null)
			dispathUtil = new DispathUtil();
		return dispathUtil;
	}

	public Map<String, Object> disPatchIncident(String descript) {
		List<String> userList = new ArrayList<String>();
		List<String> depatList=new ArrayList<>();
		Map<String, Object> mapList = new HashMap<>();
		if (descript.contains("垃圾")||descript.contains("污染")) {
			//dealer
			userList.add(ITS.getAc(UserAccount.zhangsan));
			userList.add(ITS.getAc(UserAccount.lisi));
			//depart
			depatList.add(ITS.getDepat(Departemt.HBJ));
			depatList.add(ITS.getDepat(Departemt.CHGLXZZFJ));
			//result map
			mapList.put("incidentType", ITS.getJX(IncidentType.SRHJ));
			mapList.put("departName", depatList);
			mapList.put("userArr", userList);
		} else if (descript.contains("损坏") || descript.contains("旧损")) {
			//dealer
			userList.add(ITS.getAc(UserAccount.lisi));
			//depart
			depatList.add(ITS.getDepat(Departemt.CHGLXZZFJ));
			//result map
			mapList.put("incidentType", ITS.getJX(IncidentType.GYSS));
			mapList.put("departName", depatList);
			mapList.put("userArr", userList);
		} else {
			
		}
		return mapList;
	}
}
