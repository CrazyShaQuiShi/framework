package com.dd.dispatch.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dd.dispatch.util.DispathUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Api("事件解析接口")
@Controller
public class DispatchController {

	private DispathUtil du = DispathUtil.getInstance();

	@ApiOperation(value = "测试时间解析", httpMethod = "GET")
	@RequestMapping(value = "/dispatch/{descript}", method = RequestMethod.GET)
	@ResponseBody
	public Map<String, Object> dispatchIncident(
			@ApiParam(name = "descript") @PathVariable("descript") String descript) {
		return du.disPatchIncident(descript);
	}

}
