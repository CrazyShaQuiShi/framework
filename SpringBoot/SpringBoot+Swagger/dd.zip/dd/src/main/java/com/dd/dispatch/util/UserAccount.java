package com.dd.dispatch.util;

public enum UserAccount {
	zhangsan, lisi, wangwu, zhaoliu
}
