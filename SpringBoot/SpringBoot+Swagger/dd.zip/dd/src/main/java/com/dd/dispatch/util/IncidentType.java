package com.dd.dispatch.util;

public enum IncidentType {
	/**
	 * 公用设施
	 */
	GYSS,
	/**
	 * 道路交通
	 */
	DLJT,
	/**
	 * 市容环境
	 */
	SRHJ,
	/**
	 * 园林绿化
	 */
	YLLH,
	/**
	 * 房屋土地
	 */
	ZFTD,
	/**
	 * 其他设施
	 */
	Default
}
