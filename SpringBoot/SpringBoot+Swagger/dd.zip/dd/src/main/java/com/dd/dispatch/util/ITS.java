package com.dd.dispatch.util;

/**
 * @author ShaZhengBo
 * @datetime create:2016年9月29日下午1:32:42
 * @updatetime :
 * @updateauthor:
 * @category :
 * @describe :
 */

public class ITS {

	/**
	 * Analytical data information to return the result
	 * 
	 * @param it
	 * @return String
	 */
	public static String getJX(IncidentType it) {
		switch (it) {
		case SRHJ:
			return "市容环境";
		case GYSS:
			return "公共设施";
		case ZFTD:
			return "房屋土地";
		case YLLH:
			return "园林绿化";
		default:
			return "无法解析";
		}
	}

	public static String getAc(UserAccount ua) {
		switch (ua) {
		case zhangsan:
			return "张三";
		case lisi:
			return "李四";
		case wangwu:
			return "王五";
		case zhaoliu:
			return "赵刘";
		default:
			return "相关人员";
		}
	}

	/**
	 * get about depart
	 * @param depart
	 * @return
	 */
	public static String getDepat(Departemt depart) {
		switch (depart) {
		case CHGLXZZFJ:
			return "城市管理行政执法局";
		case JZGCGLJ:
			return "建筑工程管理局";
		case JTJ:
			return "交通局";
		case MZJ:
			return "民政局";
		case QXJ:
			return "气象局";
		case SLJ:
			return "水利局";
		case WGXJ:
			return "文广新局";
		case XQB:
			return "新区办";
		case XFJ:
			return "信访局";
		case ZGDXWLFGS:
			return "中国电信温岭分公司";
		case ZGLTWLFGS:
			return "中国联通（网通）温岭分公司";
		case ZGYDWLFGS:
			return "中国移动（铁通）温岭分公司";
		case GSJ:
			return "工商局";
		case GAJ:
			return "公安局";
		case GBDT:
			return "广播电视台";
		case XZZFJ:
			return "行政执法局";
		case HBJ:
			return "环保局";
		case JSGHJ:
			return "建设规划局";
		case GDJ:
			return "供电局";
		default:
			return "相关部门";
		}
	}

}
