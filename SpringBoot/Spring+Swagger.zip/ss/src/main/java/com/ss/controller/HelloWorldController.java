package com.ss.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api("���Խӿ�")
@Controller
public class HelloWorldController {
	
	@ApiOperation(value="����",httpMethod="GET")
	@RequestMapping("/a")
	public String hello(String a){
		System.out.println(a);
		return "/index";
	}

	public String index(){
		return "/index";
	}
}
