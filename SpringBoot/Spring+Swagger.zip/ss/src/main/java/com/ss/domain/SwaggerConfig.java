package com.ss.domain;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.request.async.DeferredResult;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfig {

	@Bean
	public Docket demoApi() {
		return new Docket(DocumentationType.SWAGGER_2).groupName("logserver").genericModelSubstitutes(DeferredResult.class)
				// .genericModelSubstitutes(ResponseEntity.class)
				.useDefaultResponseMessages(false).forCodeGeneration(false).pathMapping("/").select()
				// .paths((regex("/demo/.*")))//杩囨护鐨勬帴鍙�
				.paths(PathSelectors.any()).build().apiInfo(demoApiInfo());
	}

	@SuppressWarnings("deprecation")
	private ApiInfo demoApiInfo() {
		ApiInfo apiInfo = new ApiInfo("Electronic Health Record(EHR) Platform API", // 澶ф爣棰�
				"EHR Platform's REST API, for system administrator", // 灏忔爣棰�
				"1.0", // 鐗堟湰
				"NO terms of service", "sinostrid.com", // 浣滆��
				"The Apache License, Version 2.0", // 閾炬帴鏄剧ず鏂囧瓧
				"http://www.apache.org/licenses/LICENSE-2.0.html"// 缃戠珯閾炬帴
		);

		return apiInfo;
	}

}
