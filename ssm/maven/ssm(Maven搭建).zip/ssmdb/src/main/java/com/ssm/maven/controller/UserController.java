package com.ssm.maven.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssm.maven.pojo.User;
import com.ssm.maven.service.UserService;

@Controller
@RequestMapping(value="/User")
public class UserController {

	
	@Resource(name="userService")
	private UserService userService;
	@RequestMapping(value="/login")
	public String login(){
		System.out.println("aaaaaaaaaaaaaa");
		User user=userService.getUserById(1);
		System.out.println(user);
		return "success";
	}
}
