package com.ssm.maven.service;

import com.ssm.maven.pojo.User;

public interface UserService {
	public User getUserById(int id);
}
