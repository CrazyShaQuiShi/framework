package com.ssm.maven.mapper;

import com.ssm.maven.pojo.User;

public interface UserMapper {
	public User getUserById(int id);

}
