package com.ssm.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssm.paramhelp.ParamHasMap;

@Controller
@RequestMapping(value = "/ParamHasMap")
public class ParamHasMapController {

	@RequestMapping(value = "/index")
	public String index() {
		return "success";
	}

	@RequestMapping(value = "/hasmap")
	public String paramHasMap(ParamHasMap param) {
		System.out.println(param.getParam().get("name"));
		return "success";
	}
}
