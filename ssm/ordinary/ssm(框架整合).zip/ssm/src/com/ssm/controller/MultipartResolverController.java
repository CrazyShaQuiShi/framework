package com.ssm.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RequestMapping(value = "/MuiltPartResolver")
public class MultipartResolverController {

	@RequestMapping(value = "/test")
	public String testIndex(HttpServletRequest request) {
		String a = request.getParameter("id");
		System.out.println(a);
		return "success";
	}

	@RequestMapping(value = "/upload")
	public String upload(@RequestParam("desc") String desc, @RequestParam("file") MultipartFile file)
			throws IOException {
		System.out.println("aaaaaaaaaaaaaaaa");
		String filename = file.getOriginalFilename();
		System.out.println("文件名称是:"+filename);
		System.out.println("文件流是:"+file.getInputStream());;
		return "success";
	}

}
