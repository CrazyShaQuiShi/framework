package com.ssm.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ssm.pojo.User;
import com.ssm.service.UserService;

@Controller
@RequestMapping("/Json")
public class JsonController {

	@Resource(name = "userService")
	private UserService userService;

	@ResponseBody
	@RequestMapping("/getUserJson")
	public User getUser() {
		return userService.getUserById(1);
	}
}
