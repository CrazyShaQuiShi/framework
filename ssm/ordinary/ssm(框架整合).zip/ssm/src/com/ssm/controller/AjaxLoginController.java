package com.ssm.controller;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ssm.pojo.User;
import com.ssm.service.UserService;

@Controller
@RequestMapping(value = "/Ajax")
public class AjaxLoginController {

	@Resource(name = "userService")
	private UserService userService;

	@ResponseBody
	@RequestMapping(value = "/login")
	public Map<String, Object> login(User user) {
		Map<String, Object> map = new HashMap<>();
		User getUser = userService.getUserByNameAndPwd(user);
		if (getUser != null) {
			map.put("result", "success");
		} else
			map.put("result", "default");
		return map;
	}
}
