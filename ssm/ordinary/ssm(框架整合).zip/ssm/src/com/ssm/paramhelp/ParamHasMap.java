package com.ssm.paramhelp;

import java.util.HashMap;

public class ParamHasMap {
	private HashMap<String, String> param = new HashMap<>();
	public HashMap<String, String> getParam() {
		return param;
	}
	public void setParam(HashMap<String, String> param) {
		this.param = param;
	}
}
