package com.ssm.service.impl;

import static org.junit.Assert.*;

import org.junit.Test;

public class a {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
