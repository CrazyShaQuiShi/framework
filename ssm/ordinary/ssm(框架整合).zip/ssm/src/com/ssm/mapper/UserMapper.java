package com.ssm.mapper;

import com.ssm.pojo.User;

public interface UserMapper {
	/**
	 * 根据用户id查询用户信息
	 * 
	 * @param id
	 * @return
	 */
	public User getUserById(int id);

	/**
	 * 根据用户name和pwd查看用户是否存在
	 * 
	 * @param user
	 * @return user
	 */
	public User getUserByNameAndPwd(User user)throws Exception;

}
